INVCONFIG = {}
INVCONFIG.startWeight = 10 --Weight the inventory has initially
INVCONFIG.useCharacters = true
INVCONFIG.dermaSkin = "KInventoryBasic"