local MODULE = {}

MODULE.Name = "Daily Rewards / Advent Calendar"
MODULE.Author = "Kamshak"

MODULE.Blueprints = {}

MODULE.SettingButtons = {
}

MODULE.Settings = {}

MODULE.Settings.Shared = {}

MODULE.Settings.Server = {}

Pointshop2.RegisterModule( MODULE )
