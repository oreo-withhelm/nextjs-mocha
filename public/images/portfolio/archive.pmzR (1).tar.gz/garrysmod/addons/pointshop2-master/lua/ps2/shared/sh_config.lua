Pointshop2.Config = {}
local Config = Pointshop2.Config

/*
	Skin to use
*/
Config.DermaSkin = "PS2FlatUI"