GLib.Net.ConnectionPacketType = GLib.Enum (
	{
		Open  = 1,
		Data  = 2,
		Close = 4
	}
)