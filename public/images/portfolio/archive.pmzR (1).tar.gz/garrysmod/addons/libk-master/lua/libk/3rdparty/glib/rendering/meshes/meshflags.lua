GLib.Rendering.Meshes.MeshFlags = GLib.Enum (
	{
		None    = 0,
		Dynamic = 1
	}
)