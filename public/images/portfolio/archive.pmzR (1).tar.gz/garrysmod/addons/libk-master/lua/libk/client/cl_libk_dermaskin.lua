surface.CreateFont( "LibKText", {
	font = "Segoe UI Semilight 8",
	size = 11
} )

surface.CreateFont( "LibKElement", {
	font = "Segoe UI",
	size = 9
} )

surface.CreateFont( "LibKHeading", {
	font = "Segoe UI Light", 
	size = 20
} )

surface.CreateFont( "LibKLarge", {
	font ="Segoe UI Light", 
	size = 42,
	weight = 300
} )