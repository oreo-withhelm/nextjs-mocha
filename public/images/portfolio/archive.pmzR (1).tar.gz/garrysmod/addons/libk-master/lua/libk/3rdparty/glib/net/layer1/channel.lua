local self = {}
GLib.Net.Layer1.Channel = GLib.MakeConstructor (self, GLib.Net.IChannel)