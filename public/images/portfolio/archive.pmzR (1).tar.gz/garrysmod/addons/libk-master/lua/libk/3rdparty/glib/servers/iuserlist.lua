local self = {}
GLib.IUserList = GLib.MakeConstructor (self)