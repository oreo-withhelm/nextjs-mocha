GLib.Lua.StackCaptureOptions = GLib.Enum (
	{
		None      = 0,
		Arguments = 1,
		Locals    = 2,
		Upvalues  = 4
	}
)
