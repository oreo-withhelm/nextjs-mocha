GLib.Net.ConnectionEndpoint = GLib.Enum (
	{
		Local  = 1,
		Remote = 2
	}
)