GLib.Threading.WaitEndReason = GLib.Enum (
	{
		Success = 1,
		Timeout = 2
	}
)