GLib.Rendering.Textures.PixelFormat = GLib.Enum (
	{
		R8G8B8   = 0,
		B8G8R8   = 1,
		R8G8B8A8 = 2,
		B8G8R8A8 = 3
	}
)