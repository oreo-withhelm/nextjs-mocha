local self = {}
GLib.Net.Layer5.Channel = GLib.MakeConstructor (self, GLib.Net.IChannel)