GLib.Rendering.Buffers.BufferElementType = GLib.Enum (
	{
		UInt8   =  0,
		UInt82  =  1,
		UInt83  =  2,
		UInt84  =  3,
		UInt16  =  4,
		UInt32  =  5,
		Float   =  6,
		Float2  =  7,
		Float3  =  8,
		Float4  =  9,
		Float16 = 10
	}
)