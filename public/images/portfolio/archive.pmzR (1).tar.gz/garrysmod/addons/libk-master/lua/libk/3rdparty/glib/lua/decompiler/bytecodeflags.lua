GLib.Lua.BytecodeFlags = GLib.Enum (
	{
		BigEndian                = 0x01,
		DebugInformationStripped = 0x02,
		FFI                      = 0x04
	}
)